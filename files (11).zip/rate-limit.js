// Netlify Edge Function — Rate Limiter
// Limits each IP to 60 requests per minute across the site

const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS = 60;

// In-memory store (resets per edge instance, good enough for static sites)
const ipStore = new Map();

export default async function handler(request, context) {
  const ip = context.ip || request.headers.get("x-forwarded-for") || "unknown";
  const now = Date.now();

  if (!ipStore.has(ip)) {
    ipStore.set(ip, { count: 1, windowStart: now });
  } else {
    const entry = ipStore.get(ip);
    if (now - entry.windowStart > WINDOW_MS) {
      // Reset window
      ipStore.set(ip, { count: 1, windowStart: now });
    } else {
      entry.count++;
      if (entry.count > MAX_REQUESTS) {
        return new Response("Too Many Requests — please slow down.", {
          status: 429,
          headers: {
            "Retry-After": "60",
            "Content-Type": "text/plain",
          },
        });
      }
    }
  }

  return context.next();
}

export const config = { path: "/*" };
